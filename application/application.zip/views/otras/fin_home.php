
<div class="">
		<div class="container">
			<div class="row">

				<!-- Features Title -->
				<div class="col-lg-6 ">
				</div>

				<div class="col-lg-6 ">
				<div class="hex hex-st-1">		
					<div class="inner">
						<h5>PAYMENTS</h5>						
						<a href="#!/login"></a>
					</div>		
					
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>	

				<div class="hex hex-st-2">		
					<div class="inner">
						<h5>INVEST MANAGEMENT</h5>						
					</div>	
					<a href="#"></a>		
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>

				<div class="hex hex-st-3" style="background-image: url(images/2.jpg);">		
					<div class="inner">
							<h5>CROWDFUNDING</h5>
					</div>	
					<a href="#"></a>		
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>

				<div class="hex hex-st-4">		
					<div class="inner">
							<h5> TRADING</h5>
					</div>	
					<a href="#"></a>		
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>

				<div class="hex hex-st-5" style="background-image: url(images/2.jpg);">		
					<div class="inner">
							<h5>REWARDS PLAN</h5>
					</div>	
					<a href="#"></a>		
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>

				<div class="hex hex-st-6" style="background-image: url(lib/images/2.jpg);">		
					<div class="inner">
						<h5>CRIPTO CURRENCY</h5>
					</div>	
					<a href="#"></a>		
					<div class="corner-1"></div>
					<div class="corner-2"></div>		
				</div>
				</div>
			</div>
		</div>
	</div>
