<div class="container-container">
	<div class="row">
		<div class="col-lg-5">
			<div id="default-tree" style="font-size:24pt !important;"> </div>
		</div>
	</div>
</div>


<div class="modal fade" id="modalInfo" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" >
								<form name="Form" id="Form">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header bg-light">
												<h5 class="modal-title" id="exampleModalLabel">Información de {{userData.nombre}} {{userData.apellidos}}  (USUARIO: <span class="text-primary">{{userData.nombre_usuario}}</span>)</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<div class="modal-body container">
																	
											</div>
											<div class="modal-footer ">
												<button type="button" class="btn btn-outline-light" data-dismiss="modal" ><span></span>Cerrar</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						
