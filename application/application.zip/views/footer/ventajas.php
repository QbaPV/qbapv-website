<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 mx-auto">
      <div class="card-backoffice text-center"> 
        <font color="">VENTAJAS DE SER MIEMBRO ACTIVO</font> 
      </div>
    </div>
  </div>
</div>
<div class="site-section mt-4 container p-5 data-backoffice"  style="opacity:0.8">
<p class="lead text-justify" >
  La fidelización es la forma en la que Ublof premiará y recompensará a sus usuarios no sólo por la compra de nuestros productos, sino también por la recomendación de todos los servicios y productos de los que disponemos, por los que recompensará al usuario de forma vitalicia. Con la mentalidad y valores que fundamentan nuestra compañía, serán múltiples los beneficios para el usuario, teniendo en cuenta que la empresa siempre pensará en el usuario. Además, las ganancias de los usuarios por el trabajo tanto de recomendación, así como la realización de múltiples tareas que iremos programando, la compra de nuestros productos, etc., serán altas.
</p>
<p class="lead text-justify pt-3" >
  Entre los beneficios que los Usuarios Activos tendrán, se encuentran:
</p>
<ul>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i> 	Comisiones vitalicias de las compras de sus referidos directos.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Obtención de puntos para el Loyalty Program.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Acceso a ofertas y promociones especiales (Según tipo de usuario)</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Pertenecer a una empresa con grandes valores y mentalidad emprendedora.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i> 	Productos de alta calidad y grandes beneficios.</p>
  </li>

</ul>
</div>