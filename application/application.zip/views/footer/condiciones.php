<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 mx-auto">
      <div class="card-backoffice text-center"> 
        <font color="">TÉRMINOS Y CONDICIONES</font> 
      </div>
    </div>
  </div>
</div>
<div class="site-section">
<p class="lead">
  Estos términos y condiciones son un acuerdo entre Ublof y el usuario de nuestro sitio web. Este Acuerdo establece los términos y condiciones generales del uso del sitio web www.ublof.com y cualquiera de sus productos.
</p>
</div>