<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 mx-auto">
      <div class="card-backoffice text-center"> 
        <font color="">¿CÓMO SER UN USUARIO ACTIVO?</font> 
      </div>
    </div>
  </div>
</div>
<div class="site-section mt-4 container p-5 data-backoffice"  style="opacity:0.8">
<p class="lead text-justify" >  
  Para ser un usuario activo solo debe cumplir alguno de los siguientes parámetros:
</p>
<ul>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Comprar al menos un Plan.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	 Compartir nuestros productos al menos 20 veces al mes en redes sociales.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Recomendar y registrar amigos (al menos 3 mensuales)</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i>	Compartir nuestra web 2 veces por semana.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i> Comprar Participaciones.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i> Participar en nuestro blog una vez por semana.</p>
  </li>
  <li>
      <p class="lead"> <i class="icon-hand-o-right"></i> Promoción de banners en su sitio web.</p>
  </li>

</ul>
</div>