<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 mx-auto">
      <div class="card-backoffice text-center"> 
        <font color="">Bienvenido a nuestro oblog</font> 
      </div>
    </div>
  </div>
</div>