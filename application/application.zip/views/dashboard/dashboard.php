<div !loading ng-show="cargando"></div>
<div  class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                  <h2 class=" text-center display-4 text-secondary text-uppercase ">DASHBOARD</h2>
                  <hr>
                  <!-- <p class="card-description">
                     <button type="button" class="btn btn-outline-primary btn-icon-text" data-target="#rolModal" data-toggle="modal" ng-click="ClearForm()">
                          <i class="ti-plus btn-icon-prepend"></i>                                                    
                          Agregar
                    </button>
                  </p> -->
                  
                </div>
            </div>

</div>